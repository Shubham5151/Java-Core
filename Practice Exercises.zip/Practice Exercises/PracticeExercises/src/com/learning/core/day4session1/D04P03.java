package com.learning.core.day4session1;

import java.util.Stack;

public class D04P03 {
    public static int evaluateExpression(String expression) {
        Stack<Integer> stack = new Stack<>();

        int result = 0;
        int num = 0;
        char sign = '+';

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            if (Character.isDigit(ch)) {
                num = num * 10 + (ch - '0');
            }

            if (!Character.isDigit(ch) && ch != ' ' || i == expression.length() - 1) {
                if (sign == '+') {
                    stack.push(num);
                } else if (sign == '-') {
                    stack.push(-num);
                } else if (sign == '*') {
                    stack.push(stack.pop() * num);
                } else if (sign == '/') {
                    stack.push(stack.pop() / num);
                }

                sign = ch;
                num = 0;
            }
        }

        while (!stack.isEmpty()) {
            result += stack.pop();
        }

        return result;
    }

    public static void main(String[] args) {
        String expression = "10 + 2*6";
        int result = evaluateExpression(expression);
        System.out.println("Output: " + result);
    }
}
