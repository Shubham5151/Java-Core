package com.learning.core.day4session1;

import java.util.Scanner;

class Node {
    double data;
    Node next;

    Node(double data) {
        this.data = data;
        this.next = null;
    }
}

class Stack {
    private Node top;

    public Stack() {
        this.top = null;
    }

    public void push(double data) {
        Node newNode = new Node(data);
        if (top == null) {
            top = newNode;
        } else {
            newNode.next = top;
            top = newNode;
        }
    }

    public double pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return Double.MIN_VALUE;
        } else {
            double poppedElement = top.data;
            top = top.next;
            return poppedElement;
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        } else {
            Node temp = top;
            while (temp != null) {
                System.out.print(temp.data + " ");
                temp = temp.next;
            }
            System.out.println();
        }
    }
}

public class D04P02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter space-separated double values to push onto the stack:");

        String[] input = scanner.nextLine().split(" ");
        Stack stack = new Stack();

        for (String value : input) {
            stack.push(Double.parseDouble(value));
        }

        System.out.println("Stack elements:");
        stack.display();
    }
}
