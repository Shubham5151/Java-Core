package com.learning.core.day4session1;

class Queue {
    private int front, rear, capacity;
    private int[] array;

    public Queue(int capacity) {
        this.capacity = capacity;
        this.front = 0;
        this.rear = -1;
        this.array = new int[capacity];
    }

    public void enqueue(int item) {
        if (isFull()) {
            System.out.println("Queue Overflow! Cannot enqueue " + item);
            return;
        }
        rear = (rear + 1) % capacity;
        array[rear] = item;
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow! Cannot dequeue.");
            return -1;
        }
        int dequeuedItem = array[front];
        front = (front + 1) % capacity;
        return dequeuedItem;
    }

    public boolean isEmpty() {
        return (rear == -1);
    }

    public boolean isFull() {
        return ((rear + 1) % capacity == front);
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        System.out.print("Elements in queue: ");
        int i = front;
        while (i != rear) {
            System.out.print(array[i] + " ");
            i = (i + 1) % capacity;
        }
        System.out.println(array[rear]);
    }
}

public class D04P05 {
    public static void main(String[] args) {
        Queue queue = new Queue(5);

       
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);

        
        queue.display();

       
        int dequeuedItem = queue.dequeue();
        System.out.println("After removing first element: ");
        queue.display();
    }
}
