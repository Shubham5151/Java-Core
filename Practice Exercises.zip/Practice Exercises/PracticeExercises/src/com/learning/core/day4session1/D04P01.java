package com.learning.core.day4session1;



	class Stack {
	    private int maxSize;
	    private String[] stackArray;
	    private int top;

	    public Stack(int maxSize) {
	        this.maxSize = maxSize;
	        this.stackArray = new String[maxSize];
	        this.top = -1;
	    }

	    public void push(String element) {
	        if (top == maxSize - 1) {
	            System.out.println("Stack Overflow! Cannot push " + element);
	        } else {
	            stackArray[++top] = element;
	            System.out.println("Pushed: " + element);
	        }
	    }

	    public String pop() {
	        if (top == -1) {
	            System.out.println("Stack Underflow! Cannot pop.");
	            return null;
	        } else {
	            String poppedElement = stackArray[top--];
	            System.out.println("Popped: " + poppedElement);
	            return poppedElement;
	        }
	    }

	    public void display() {
	        System.out.print("Stack: ");
	        for (int i = 0; i <= top; i++) {
	            System.out.print(stackArray[i] + " ");
	        }
	        System.out.println();
	    }
	}

	public class D04P01 {
	    public static void main(String[] args) {
	        Stack stack = new Stack(5);

	       
	        stack.push("Hello");
	        stack.push("world");
	        stack.push("java");
	        stack.push("Programming");

	        stack.display();

	        stack.pop();

	     
	        stack.display();
	    }
	}
