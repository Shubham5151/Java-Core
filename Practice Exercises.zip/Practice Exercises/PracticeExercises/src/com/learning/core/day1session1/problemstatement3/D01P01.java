package com.learning.core.day1session1.problemstatement3;

import java.util.Scanner;

public class D01P01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        
        if (scanner.hasNextInt()) {
            int number = scanner.nextInt();
            if (number >= 0) {
                int factorial = calculateFactorial(number);
                System.out.println("Factorial of " + number + " is " + factorial);
            } else {
                System.out.println("Invalid Input: Please enter a non-negative integer.");
            }
        } else {
            System.out.println("Invalid Input: Please enter an integer.");
            scanner.next(); 
        }
        
        scanner.close();
    }
    
    public static int calculateFactorial(int n) {
        if (n == 0)
            return 1;
        int factorial = 1;
        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        return factorial;
    }
}
