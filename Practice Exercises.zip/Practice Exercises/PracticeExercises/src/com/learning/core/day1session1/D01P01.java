package com.learning.core.day1session1;

public class D01P01 {
    private String book_title;
    private double book_price;

   
    public String getBookTitle() {
        return book_title;
    }

    public void setBookTitle(String title) {
        this.book_title = title;
    }

    public double getBookPrice() {
        return book_price;
    }

    public void setBookPrice(double price) {
        this.book_price = price;
    }

   
    public static D01P01 createBook(String title, double price) {
        D01P01 book = new D01P01();
        book.setBookTitle(title);
        book.setBookPrice(price);
        return book;
    }

  
    public static void showBook(D01P01 book) {
        System.out.println("Book Title: " + book.getBookTitle() + " and Price: " + book.getBookPrice());
    }

    public static void main(String[] args) {
        // Input
        String title = "Java Programming";
        double price = 350.00;

     
        D01P01 book = createBook(title, price);

        showBook(book);
    }
}
