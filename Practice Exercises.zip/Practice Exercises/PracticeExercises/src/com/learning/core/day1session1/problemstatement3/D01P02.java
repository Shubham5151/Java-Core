package com.learning.core.day1session1.problemstatement3;

import java.util.Scanner;

public class D01P02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the marks obtained: ");
        
        if (scanner.hasNextInt()) {
            int marks = scanner.nextInt();
            double percentage = calculatePercentage(marks);
            String grade = calculateGrade(percentage);
            System.out.println("Grade: " + grade);
        } else {
            System.out.println("Invalid Input");
            scanner.next();
        }
        
        scanner.close();
    }
    
    public static double calculatePercentage(int marks) {
        
        return (marks / 100.0) * 100;
    }
    
    public static String calculateGrade(double percentage) {
        if (percentage >= 60) {
            return "A Grade";
        } else if (percentage >= 45) {
            return "B Grade";
        } else if (percentage >= 35) {
            return "C Grade";
        } else {
            return "Fail";
        }
    }
}
