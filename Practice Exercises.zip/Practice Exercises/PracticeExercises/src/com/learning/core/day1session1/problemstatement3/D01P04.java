package com.learning.core.day1session1.problemstatement3;

import java.util.Scanner;

public class D01P04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of rows: ");
        
        if (scanner.hasNextInt()) {
            int numRows = scanner.nextInt();
            printPattern(numRows);
        } else {
            System.out.println("Invalid Input");
        }
        
        scanner.close();
    }
    
    public static void printPattern(int numRows) {
        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(i);
            }
            System.out.println();
        }
    }
}
