package com.learning.core.day1session1.problemstatement3;

import java.util.Scanner;

public class D01P05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a number representing a day of the week (1-7): ");
        
        if (scanner.hasNextInt()) {
            int dayNumber = scanner.nextInt();
            String weekday = getWeekday(dayNumber);
            if (weekday != null) {
                System.out.println(weekday);
            } else {
                System.out.println("Invalid Input");
            }
        } else {
            System.out.println("Invalid Input");
            scanner.next(); 
        }
        
        scanner.close();
    }
    
    public static String getWeekday(int dayNumber) {
        if (dayNumber >= 1 && dayNumber <= 7) {
            switch (dayNumber) {
              
                case 1: return "Monday";
                case 2: return "Tuesday";
                case 3: return "Wednesday";
                case 4: return "Thursday";
                case 5: return "Friday";
                case 6: return "Saturday";
                case 7: return "Sunday";
                default: return null; 
            }
        } else {
            return null; 
        }
    }
}
