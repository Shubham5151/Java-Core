package com.learning.core.day2session1;

import java.util.*;

public class StringChainCircleProb5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of strings: ");
        int n = scanner.nextInt();
        scanner.nextLine(); 
        
       
        System.out.println("Enter the strings:");
        String[] strings = new String[n];
        for (int i = 0; i < n; i++) {
            strings[i] = scanner.nextLine();
        }

        List<String> result = findCircle(strings);

    
        if (result != null) {
            System.out.println("Yes");
            for (String str : result) {
                System.out.print(str + " ");
            }
            System.out.println();
        } else {
            System.out.println("No");
        }

        scanner.close();
    }

    public static List<String> findCircle(String[] strings) {
        List<String> result = new ArrayList<>();
        Set<Integer> visited = new HashSet<>();
        if (findCircleHelper(strings, visited, result)) {
            return result;
        }
        return null;
    }

    public static boolean findCircleHelper(String[] strings, Set<Integer> visited, List<String> result) {
        if (visited.size() == strings.length) {
            return result.get(result.size() - 1).charAt(result.get(result.size() - 1).length() - 1) ==
                   result.get(0).charAt(0);
        }

        String last = result.isEmpty() ? "" : result.get(result.size() - 1);
        char lastChar = last.isEmpty() ? Character.MIN_VALUE : last.charAt(last.length() - 1);
        for (int i = 0; i < strings.length; i++) {
            if (!visited.contains(i) && strings[i].charAt(0) == lastChar) {
                visited.add(i);
                result.add(strings[i]);
                if (findCircleHelper(strings, visited, result)) {
                    return true;
                }
                visited.remove(i);
                result.remove(result.size() - 1);
            }
        }
        return false;
    }
}
