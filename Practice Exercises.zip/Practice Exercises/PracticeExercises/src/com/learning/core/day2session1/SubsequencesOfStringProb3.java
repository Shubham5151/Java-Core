package com.learning.core.day2session1;

import java.util.*;

public class SubsequencesOfStringProb3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
       
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        System.out.println("All subsequences of the string:");
        printSubsequences(input);
        
        scanner.close();
    }
    
    public static void printSubsequences(String str) {
        printSubsequencesHelper(str, 0, "");
    }
    
    private static void printSubsequencesHelper(String str, int index, String current) {
        if (index == str.length()) {
            if (!current.isEmpty()) {
                System.out.print(current + ", ");
            }
            return;
        }
        
      
        printSubsequencesHelper(str, index + 1, current + str.charAt(index));
        
        printSubsequencesHelper(str, index + 1, current);
    }
}
