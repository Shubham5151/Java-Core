package com.learning.core.day2session1;

import java.util.Scanner;

public class ReplaceSpacesProb9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

       
        String result = replaceSpaces(input);

        
        System.out.println("Result: " + result);

        scanner.close();
    }

    public static String replaceSpaces(String str) {
        StringBuilder result = new StringBuilder();

        for (char ch : str.toCharArray()) {
            if (ch == ' ') {
                result.append("%20");
            } else {
                result.append(ch);
            }
        }

        return result.toString();
    }
}
