package com.learning.core.day2session1;

import java.util.Scanner;

public class LastNVowelCounterProb2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();

       
        String result = countLastNVowels(input, n);

     
        System.out.println("Last " + n + " vowels: " + result);

        scanner.close();
    }

    public static String countLastNVowels(String str, int n) {
       
        str = str.toLowerCase();

        StringBuilder vowels = new StringBuilder();
        int vowelCount = 0;

       
        for (int i = str.length() - 1; i >= 0; i--) {
            char ch = str.charAt(i);
            if (isVowel(ch)) {
                vowels.insert(0, ch); 
                vowelCount++;
                if (vowelCount == n) {
                    break; 
                }
            }
        }

       
        while (vowelCount < n) {
            vowels.insert(0, ' ');
            vowelCount++;
        }

        return vowels.toString();
    }

    public static boolean isVowel(char ch) {
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }
}
