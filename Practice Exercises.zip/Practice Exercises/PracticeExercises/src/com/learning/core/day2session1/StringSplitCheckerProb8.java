package com.learning.core.day2session1;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class StringSplitCheckerProb8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

     
        boolean canSplit = checkStringSplit(input);

       
        if (canSplit) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

        scanner.close();
    }

    public static boolean checkStringSplit(String str) {
        int n = str.length();
        Set<String> substrings = new HashSet<>();

        
        for (int i = 1; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                for (int k = j + 1; k < n; k++) {
                    String s1 = str.substring(0, i);
                    String s2 = str.substring(i, j);
                    String s3 = str.substring(j, k);
                    String s4 = str.substring(k, n);

                 
                    if (substrings.contains(s1) || substrings.contains(s2) ||
                        substrings.contains(s3) || substrings.contains(s4)) {
                        continue;
                    }

                   
                    substrings.add(s1);
                    substrings.add(s2);
                    substrings.add(s3);
                    substrings.add(s4);

                    
                    if (substrings.size() == 4) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
