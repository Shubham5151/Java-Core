package com.learning.core.day2session1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.*;

public class PatternMatchingProb7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the dictionary (space-separated strings):");
        String dictionaryInput = scanner.nextLine();
        String[] dictionary = dictionaryInput.split(" ");
        System.out.print("Enter the pattern: ");
        String pattern = scanner.nextLine();

       
        List<String> matches = findPatternMatches(dictionary, pattern);

        // Output the matches
        System.out.println("Strings in the dictionary that match the pattern:");
        for (String match : matches) {
            System.out.println(match);
        }

        scanner.close();
    }

    public static List<String> findPatternMatches(String[] dictionary, String pattern) {
        List<String> matches = new ArrayList<>();
        Pattern regex = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);

        for (String word : dictionary) {
            Matcher matcher = regex.matcher(word);
            if (matcher.matches()) {
                matches.add(word);
            }
        }

        return matches;
    }
}
