package com.learning.core.day1session2;

import java.util.*;

public class FirstRepeatingElementIndex {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int N = scanner.nextInt();

        
        System.out.println("Enter the elements of the array separated by spaces:");
        int[] arr = new int[N];
        for (int i = 0; i < N; i++) {
            arr[i] = scanner.nextInt();
        }

        
        Map<Integer, Integer> map = new HashMap<>();

       
        int firstRepeatingIndex = -1;
        for (int i = 0; i < N; i++) {
            int num = arr[i];
            if (map.containsKey(num)) {
                firstRepeatingIndex = map.get(num);
                break;
            } else {
                map.put(num, i);
            }
        }

       
        System.out.println("Index of the first repeating element: " + firstRepeatingIndex);

        scanner.close();
    }
}
