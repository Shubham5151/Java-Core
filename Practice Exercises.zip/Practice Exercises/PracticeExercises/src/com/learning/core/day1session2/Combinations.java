package com.learning.core.day1session2;

import java.util.*;

public class Combinations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter the array of numbers separated by spaces: ");
        String input = scanner.nextLine();
        String[] arrStr = input.split(" ");
        int[] arr = new int[arrStr.length];
        for (int i = 0; i < arrStr.length; i++) {
            arr[i] = Integer.parseInt(arrStr[i]);
        }

       
        System.out.print("Enter the value of k: ");
        int k = scanner.nextInt();

       
        List<String> combinations = findCombinations(arr, k);

     
        System.out.println("Distinct combinations:");
        for (String combination : combinations) {
            System.out.println(combination);
        }

        scanner.close();
    }

    public static List<String> findCombinations(int[] arr, int k) {
        List<String> combinations = new ArrayList<>();
        findCombinationsHelper(arr, k, 0, new StringBuilder(), combinations);
        return combinations;
    }

    public static void findCombinationsHelper(int[] arr, int k, int start, StringBuilder current, List<String> combinations) {
        if (current.length() == k) {
            combinations.add(current.toString());
            return;
        }
        for (int i = start; i < arr.length; i++) {
            current.append(arr[i]);
            findCombinationsHelper(arr, k, i + 1, current.append(','), combinations);
            current.deleteCharAt(current.length() - 1);
            current.deleteCharAt(current.length() - 1);
        }
    }
}
