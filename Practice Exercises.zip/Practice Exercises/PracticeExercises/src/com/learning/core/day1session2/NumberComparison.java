package com.learning.core.day1session2;

import java.util.Scanner;

public class NumberComparison {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter two numbers between 1 and 40 separated by space: ");
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();

        
        int[] array = {7, 25, 5, 19, 30};

       
        boolean found1 = false;
        boolean found2 = false;
        for (int i = 0; i < array.length; i++) {
            if (num1 == array[i]) {
                found1 = true;
            }
            if (num2 == array[i]) {
                found2 = true;
            }
        }

       
        if (found1 && found2) {
            System.out.println("Its Bingo");
        } else {
            System.out.println("Not Found");
        }

        scanner.close();
    }
}
