package com.learning.core.day1session2;

public class D01P01 {
    public static void main(String[] args) {
        
        int[] All = {2, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0};

       
        int sum = 0;
        for (int i = 0; i < 15; i++) {
            sum += All[i];
        }
      
        All[15] = sum;

        
        double average = (double) sum / All.length;
       
        All[16] = (int) average;

      
        int smallest = All[0];
        for (int i = 1; i < All.length; i++) {
            if (All[i] < smallest) {
                smallest = All[i];
            }
        }
       
        All[14] = smallest;

       
        for (int i = 0; i < All.length; i++) {
            System.out.print(All[i]);
        }
    }
}
