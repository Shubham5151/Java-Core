package com.learning.core.day3session1;

 

	import java.util.TreeSet;

	class Person implements Comparable<Person> {
	    private int id;
	    private String name;
	    private int age;
	    private double salary;

	    public Person(int id, String name, int age, double salary) {
	        this.id = id;
	        this.name = name;
	        this.age = age;
	        this.salary = salary;
	    }

	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	    public double getSalary() {
	        return salary;
	    }

	
	    public String toString() {
	        return id + " " + name + " " + salary;
	    }

	   
	    public int hashCode() {
	        return id;
	    }

	    public boolean equals(Object obj) {
	        if (this == obj)
	            return true;
	        if (obj == null || getClass() != obj.getClass())
	            return false;
	        Person person = (Person) obj;
	        return id == person.id;
	    }

	   
	    public int compareTo(Person other) {
	        return Integer.compare(this.id, other.id);
	    }
	}

	public class D03P06 {
	    public static void main(String[] args) {
	        TreeSet<Person> personSet = new TreeSet<>();

	  
	        personSet.add(new Person(1, "Jerry", 35, 999.0));
	        personSet.add(new Person(2, "Smith", 40, 2999.0));
	        personSet.add(new Person(3, "Рореу", 45, 5999.0));
	        personSet.add(new Person(4, "Jones", 50, 6999.0));
	        personSet.add(new Person(5, "John", 25, 1999.0));
	        personSet.add(new Person(6, "Tom", 30, 3999.0));

	      
	        System.out.println("Id Name Salary");
	        for (Person person : personSet) {
	            System.out.println(person.getId() + " " + person.getName() + " " + person.getSalary());
	        }
	    }
	}
