package com.learning.core.day3session1;



	import java.util.TreeSet;

	class Person2 implements Comparable<Person2> {
	    private int id;
	    private String name;
	    private int age;
	    private double salary;

	    public Person2(int id, String name, int age, double salary) {
	        this.id = id;
	        this.name = name;
	        this.age = age;
	        this.salary = salary;
	    }

	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	    public double getSalary() {
	        return salary;
	    }

	  
	    public String toString() {
	        return "Id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary;
	    }

	   
	    public int hashCode() {
	        return id;
	    }

	    
	    public boolean equals(Object obj) {
	        if (this == obj)
	            return true;
	        if (obj == null || getClass() != obj.getClass())
	            return false;
	        Person2 person2 = (Person2) obj;
	        return id == person2.id;
	    }

	   
	    public int compareTo(Person2 other) {
	        return Integer.compare(this.id, other.id);
	    }
	}

	public class D03P08 {
	    public static void main(String[] args) {
	        TreeSet<Person2> person2Set = new TreeSet<>();

	  
	        person2Set.add(new Person2(1, "Jerry", 35, 999.0));
	        person2Set.add(new Person2(2, "Smith", 40, 2999.0));
	        person2Set.add(new Person2(3, "Popeye", 45, 5999.0));
	        person2Set.add(new Person2(4, "Jones", 50, 6999.0));
	        person2Set.add(new Person2(5, "John", 25, 1999.0));
	        person2Set.add(new Person2(6, "Tom", 30, 3999.0));

	   
	        double sum = 0.0;
	        for (Person2 person2 : person2Set) {
	            sum += person2.getSalary();
	        }

	        System.out.println("Sum of all salaries: " + sum);
	    }
	}
