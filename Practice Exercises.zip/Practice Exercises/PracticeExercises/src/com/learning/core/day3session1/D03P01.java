package com.learning.core.day3session1;
import java.util.ArrayList;
import java.util.Scanner;

public class D03P01 {
	
	
	
	    public static void main(String[] args) {
	       
	        ArrayList<String> studentList = new ArrayList<>();

	   
	        addStudentNames(studentList);

	        
	        checkNameExistence(studentList);
	    }

	    public static void addStudentNames(ArrayList<String> list) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Enter names of students separated by spaces:");
	        String input = scanner.nextLine();
	        String[] names = input.split(" ");

	        for (String name : names) {
	            list.add(name);
	        }
	    }

	    public static void checkNameExistence(ArrayList<String> list) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Enter the name to search:");
	        String nameToSearch = scanner.nextLine();

	       
	        if (list.contains(nameToSearch)) {
	            System.out.println("The name '" + nameToSearch + "'Found.");
	        } else {
	            System.out.println("The name '" + nameToSearch + "' does not exist in the list.");
	        }
	    }
	}


