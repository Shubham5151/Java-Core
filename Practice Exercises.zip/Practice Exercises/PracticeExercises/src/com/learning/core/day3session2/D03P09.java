package com.learning.core.day3session2;


	import java.util.*;

	class Employee {
	    private int id;
	    private String name;
	    private String department;
	    private String designation;

	   
	    public Employee(int id, String name, String department, String designation) {
	        this.id = id;
	        this.name = name;
	        this.department = department;
	        this.designation = designation;
	    }

	  
	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getDepartment() {
	        return department;
	    }

	    public String getDesignation() {
	        return designation;
	    }

	   
	    public String toString() {
	        return "ID: " + id + ", Name: " + name + ", Department: " + department + ", Designation: " + designation;
	    }

	   
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        Employee employee = (Employee) obj;
	        return id == employee.id &&
	                Objects.equals(name, employee.name) &&
	                Objects.equals(department, employee.department) &&
	                Objects.equals(designation, employee.designation);
	    }

	   
	    public int hashCode() {
	        return Objects.hash(id, name, department, designation);
	    }
	}

	public class D03P09 {
	    public static void main(String[] args) {
	       
	        Hashtable<Integer, Employee> employeeTable = new Hashtable<>();

	       s
	        employeeTable.put(101, new Employee(101, "John Doe", "HR", "Manager"));
	        employeeTable.put(102, new Employee(102, "Jane Smith", "Finance", "Analyst"));
	        employeeTable.put(103, new Employee(103, "Alice Johnson", "IT", "Developer"));
	        employeeTable.put(104, new Employee(104, "Bob Williams", "Marketing", "Coordinator"));

	       
	        System.out.println("Is the Hashtable empty? " + employeeTable.isEmpty());
	    }
	}
