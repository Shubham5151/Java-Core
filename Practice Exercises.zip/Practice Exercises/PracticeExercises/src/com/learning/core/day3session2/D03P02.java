package com.learning.core.day3session2;



	import java.util.HashMap;
	import java.util.Map;

	public class D03P02 {
	    public static void main(String[] args) {
	     
	        Map<String, String> phoneBook = new HashMap<>();

	       
	        phoneBook.put("Amal", "998787823");
	        phoneBook.put("Manvitha", "937843978");
	        phoneBook.put("Joseph", "7882221113");
	        phoneBook.put("Smith", "8293893311");
	        phoneBook.put("Kathe", "7234560011");

	       
	        String nameToSearch = "Joseph";
	        String phoneNumber = phoneBook.get(nameToSearch);

	       
	        if (phoneNumber != null) {
	            System.out.println("Phone number for " + nameToSearch + " is: " + phoneNumber);
	        } else {
	            System.out.println("Phone number not found for " + nameToSearch);
	        }
	    }
	}
