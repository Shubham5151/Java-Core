package com.learning.core.day3session2;



	import java.util.*;

	class Book implements Comparable<Book> {
	    private int bookId;
	    private String title;
	    private double price;
	    private Date dateOfPublication;
	    private String author;

	 
	    public Book(int bookId, String title, double price, Date dateOfPublication, String author) {
	        this.bookId = bookId;
	        this.title = title;
	        this.price = price;
	        this.dateOfPublication = dateOfPublication;
	        this.author = author;
	    }

	   
	    public int getBookId() {
	        return bookId;
	    }

	    public String getTitle() {
	        return title;
	    }

	    public double getPrice() {
	        return price;
	    }

	    public Date getDateOfPublication() {
	        return dateOfPublication;
	    }

	    public String getAuthor() {
	        return author;
	    }

	    public String toString() {
	        return bookId + " " + title + "\n" + price + " " + author + "\n" + dateOfPublication;
	    }

	   
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        Book book = (Book) obj;
	        return bookId == book.bookId &&
	                Double.compare(book.price, price) == 0 &&
	                Objects.equals(title, book.title) &&
	                Objects.equals(dateOfPublication, book.dateOfPublication) &&
	                Objects.equals(author, book.author);
	    }

	    
	    public int hashCode() {
	        return Objects.hash(bookId, title, price, dateOfPublication, author);
	    }

	    public int compareTo(Book other) {
	        return Integer.compare(this.bookId, other.bookId);
	    }
	}
	public class D03P03 {
	    public static void main(String[] args) {
	        
	        TreeSet<Book> bookSet = new TreeSet<>();

	        bookSet.add(new Book(1001, "Python Learning", 715.0, new Date(120, 1, 2), "Martic C. Brown"));
	        bookSet.add(new Book(1002, "Modern Mainframe", 295.0, new Date(97, 4, 19), "Sharad"));
	        bookSet.add(new Book(1003, "Java Programming", 523.0, new Date(84, 5, 19), "Gilad Bracha"));
	        bookSet.add(new Book(1004, "Read C++", 295.0, new Date(84, 10, 23), "Henry Harvin"));
	        bookSet.add(new Book(1005, ".Net Platform", 3497.0, new Date(84, 2, 6), "Mark J. Price"));

	     
	        for (Book book : bookSet) {
	            System.out.println(book);
	        }
	    }
	}
